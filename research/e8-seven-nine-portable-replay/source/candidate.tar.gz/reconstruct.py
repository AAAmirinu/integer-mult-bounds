"""Replay B-schedule witness on frozen PR376 helper-reuse word.
OpenAI Codex-assisted. Upstream E8 word: Dylan Crow with Claude;
PR376 frame/helper witnesses: eumemic with OpenAI Codex. Apache-2.0.
"""
import gzip, json, hashlib, sys, collections
from pathlib import Path

def reconstruct(raw,witness):
 assert hashlib.sha256(raw).hexdigest()==witness['source_sha256']
 word=json.loads(raw); before=json.loads(raw)
 word['B']=witness['B']
 def multiset(w):return collections.Counter((d,s) for f,d,ss in w['B'] for s in ss)
 assert multiset(word)==multiset(before)
 assert sum(multiset(word).values())==592
 assert all(120<=d<240 and (s<120 or s>=240) for d,s in multiset(word))
 assert all(word[k]==before[k] for k in word if k!='B')
 data=json.dumps(word,separators=(',',':'),sort_keys=True).encode()
 assert hashlib.sha256(data).hexdigest()==witness['candidate_json_sha256']
 return data

if __name__=='__main__':
 source, selection, output=map(Path,sys.argv[1:])
 data=reconstruct(source.read_bytes(),json.loads(selection.read_text()))
 with output.open('wb') as fh:
  with gzip.GzipFile(filename='',mode='wb',fileobj=fh,mtime=0) as gz:gz.write(data)
 print('PASS_FROZEN_PR376_COMMUTING_B_RECONSTRUCTION',hashlib.sha256(output.read_bytes()).hexdigest())
