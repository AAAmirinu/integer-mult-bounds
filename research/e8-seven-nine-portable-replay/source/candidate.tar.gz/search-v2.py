"""Search event orders in commuting B with fixed source-order chains.
Exploratory OpenAI Codex code. No publication/admission from this screen.
"""
import os,sys,time,json,gzip,random,heapq,itertools,collections,hashlib
from pathlib import Path
os.environ['E8COORD']='ham';sys.dont_write_bytecode=True
sys.path.insert(0,'/private/tmp/pr370-low-read-certificate-v1/producer')
import frames as Fm,fullword
ROOT=Path(__file__).resolve().parent
OUT=Path('/private/tmp/pr376-b-poset-search-v2');OUT.mkdir(exist_ok=True)
w=json.loads(gzip.decompress((ROOT/'reproduced-word.json.gz').read_bytes()))
masks=[sum(1<<s for s in f) for f in w['frames']]
dim={f:Fm.dim(f) for f in masks}
def d(f):
 if f not in dim:dim[f]=Fm.dim(f)
 return dim[f]
def join(a,b):
 if a&~b==0:return b
 if b&~a==0:return a
 return Fm.join(a,b)
initial=[masks[f]for f in w['start']]
for f,t,ss in w['A']:
 for r in [t]+ss:initial[r]=masks[f]
final=[masks[f]for f in w['final']]
edges=[(t,s)for f,t,ss in w['B']for s in ss]
sources=collections.defaultdict(list);targets=collections.defaultdict(list)
for i,(t,s)in enumerate(edges):sources[s].append(i);targets[t].append(i)
N=len(edges);S=.000993;M=56;gg=[0]+[(r/M)**(1-S)for r in range(1,9)]
def cost(f,ps,ns):
 q=d(f);return sum(gg[q-d(p)]+gg[d(n)-q]for p,n in zip(ps,ns))
base_frames=[masks[f]for f,t,ss in w['B']for s in ss]

def optimize(targets,sources,seed=None):
 prev=[[-1,-1]for _ in edges];nex=[[-1,-1]for _ in edges];indeg=[0]*N
 for side,tab in enumerate((targets,sources)):
  for row in tab.values():
   for a,b in zip(row,row[1:]):prev[b][side]=a;nex[a][side]=b;indeg[b]+=1
 ready=[i for i,x in enumerate(indeg)if x==0];heapq.heapify(ready);order=[]
 while ready:
  i=heapq.heappop(ready);order.append(i)
  for j in nex[i]:
   if j>=0:
    indeg[j]-=1
    if indeg[j]==0:heapq.heappush(ready,j)
 if len(order)!=N:return None
 lower=[0]*N;upper=[0]*N
 for i in reversed(order):
  f=[final[r]if j<0 else upper[j]for r,j in zip(edges[i],nex[i])];upper[i]=f[0]&f[1]
 for i in order:
  f=[initial[r]if j<0 else lower[j]for r,j in zip(edges[i],prev[i])];lower[i]=join(f[0],f[1])
  if lower[i]&~upper[i]:return None
 fs=lower[:]
 if seed is not None:
  for i in order:
   ps=[initial[r]if j<0 else fs[j]for r,j in zip(edges[i],prev[i])]
   fs[i]=join(join(ps[0],ps[1]),seed[i]&upper[i])
   assert fs[i]&~upper[i]==0
 for epoch in range(6):
  changed=0
  for i in order if epoch%2==0 else reversed(order):
   ps=[initial[r]if j<0 else fs[j]for r,j in zip(edges[i],prev[i])]
   ns=[final[r]if j<0 else fs[j]for r,j in zip(edges[i],nex[i])]
   lo=join(ps[0],ps[1]);hi=ns[0]&ns[1]
   best=min((fs[i],lo,hi),key=lambda f:cost(f,ps,ns))
   if cost(best,ps,ns)<cost(fs[i],ps,ns)-1e-14:fs[i]=best;changed+=1
  if changed==0:break
 # B and terminal MOVE profile; A is a common constant across all candidates.
 hist=collections.Counter()
 for side,tab in enumerate((targets,sources)):
  for r,row in tab.items():
   path=[initial[r]]+[fs[i]for i in row]+[final[r]]
   for a,b in zip(path,path[1:]):
    assert a&~b==0
    if a!=b:hist[d(b)-d(a)]+=1
 return sum(n*gg[r]for r,n in hist.items()),fs,order,hist

best=optimize(targets,sources,base_frames);assert best
print('base',best[0],dict(best[3]),flush=True)
initial_best=best[0];baseline_min=optimize(targets,sources)
print('baseline_minimum_start',baseline_min[0],dict(baseline_min[3]),flush=True)
if baseline_min[0]<best[0]-1e-14:best=baseline_min
start=time.monotonic();rng=random.Random(376);history=[];evaluated=0;infeasible=0
def save(label):
 fs,order=best[1:3];new=json.loads(json.dumps(w));fm={f:i for i,f in enumerate(masks)}
 def fid(f):
  if f not in fm:fm[f]=len(new['frames']);new['frames'].append([i for i in range(120)if f>>i&1])
  return fm[f]
 new['B']=[[fid(fs[i]),edges[i][0],[edges[i][1]]]for i in order]
 fullword.save(new,str(OUT/'candidate-word.json.gz'))
 record=dict(label=label,score=best[0],histogram=dict(best[3]),delta=best[0]-initial_best,seconds=time.monotonic()-start)
 history.append(record);(OUT/'SEARCH.json').write_text(json.dumps(dict(history=history,evaluated=evaluated,infeasible=infeasible),sort_keys=True,indent=2)+'\n');print('IMPROVE',record,flush=True)
if best[0]<initial_best-1e-14:save('baseline_minimum_start')
for round in range(3):
 improved=0;ts=list(targets);rng.shuffle(ts)
 for t in ts:
  old=targets[t];winner=None
  for perm in itertools.permutations(old):
   if list(perm)==old:continue
   targets[t]=list(perm);candidate=optimize(targets,sources,best[1]);evaluated+=1
   if candidate is None:infeasible+=1;continue
   if candidate[0]<best[0]-1e-14:best=candidate;winner=list(perm)
  if winner is not None:targets[t]=winner;improved+=1;save(['target-order',round,t])
  else:targets[t]=old
  if evaluated%1000<120:print('progress',round,t,evaluated,infeasible,'sec',time.monotonic()-start,flush=True)
 for s in sorted(sources):
  old=sources[s];winner=None
  for i,j in itertools.combinations(range(len(old)),2):
   perm=old[:];perm[i],perm[j]=perm[j],perm[i];sources[s]=perm
   candidate=optimize(targets,sources,best[1]);evaluated+=1
   if candidate is None:infeasible+=1;continue
   if candidate[0]<best[0]-1e-14:best=candidate;winner=perm
  if winner is not None:sources[s]=winner;improved+=1;save(['source-pair-swap',round,s])
  else:sources[s]=old
 print('rounddone',round,improved,'eval',evaluated,'sec',time.monotonic()-start,flush=True)
 if improved==0:break
(OUT/'RESULT.json').write_text(json.dumps(dict(status='BOUNDED_TARGET_EVENT_POSET_SCREEN',history=history,evaluated=evaluated,infeasible=infeasible,baseline=initial_best,best=best[0],seconds=time.monotonic()-start),sort_keys=True,indent=2)+'\n')
