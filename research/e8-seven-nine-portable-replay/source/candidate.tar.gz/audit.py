"""Independent scalar-equivalence and both reflected root-frame ledgers.
OpenAI Codex-assisted, Apache-2.0. Signed seven-stage admission is separate.
"""
import gzip,json,hashlib,collections,sys,os,struct
from pathlib import Path
os.environ['E8COORD']='ham';sys.dont_write_bytecode=True
sys.path.insert(0,str(Path(__file__).resolve().parent/'producer'))
import frames as Fm
P=Path(__file__).resolve().parent
old=json.loads((P/'frozen376.json').read_bytes())
new=json.loads(gzip.decompress((P/'reproduced-word.json.gz').read_bytes()))
assert old.keys()==new.keys()
same=[k for k in old if old[k]==new[k]]
assert sorted(same)==sorted(k for k in old if k!='B')
scalars=lambda w:collections.Counter((d,s)for f,d,ss in w['B']for s in ss)
assert scalars(old)==scalars(new)
assert sum(scalars(new).values())==592
assert all(120<=d<240 and (s<120 or s>=240)for d,s in scalars(new))
# A B-edge is e_dst e_src^T. Products of any two such matrices vanish,
# because dst is always a target and src is never a target. Therefore
# the two B schedules have identical integer elementary-addition products.
masks=[sum(1<<s for s in fr) for fr in new['frames']]
dims={f:Fm.dim(f)for f in masks}
paths=[[masks[f]]for f in new['start']]
for ph in ('A','B'):
 for f,d,ss in new[ph]:
  q=masks[f]
  for r in [d]+ss:
   assert Fm.inside(paths[r][-1],q)
   if q!=paths[r][-1]:paths[r].append(q)
for r,f in enumerate(new['final']):
 q=masks[f];assert Fm.inside(paths[r][-1],q)
 if q!=paths[r][-1]:paths[r].append(q)
def histogram(pp):
 h=collections.Counter()
 for path in pp:
  for a,b in zip(path,path[1:]):
   assert Fm.inside(a,b)
   h[dims[b]-dims[a]]+=1
 return h
forward=histogram(paths)
complements={}
for f in {f for path in paths for f in path}:
 comp=Fm.FULL
 for line in range(120):
  if f>>line&1:comp&=Fm.HYP[line]
 dims[comp]=Fm.dim(comp)
 assert dims[comp]+dims[f]==8,(f,dims[f],comp,dims[comp])
 complements[f]=comp
reflected=histogram([[complements[f]for f in reversed(path)]for path in paths])
assert forward==reflected
# Match actual emitted MOVE ranks, then include all nine paid retained copies.
rows=list(struct.iter_unpack('<6i',(P/'records/249-records.bin').read_bytes()))
native_moves=collections.Counter(row[4]for row in rows if row[0]==0 and row[4]>0)
assert native_moves==forward
copies=collections.Counter(row[5]for row in rows if row[0]==2 and row[5]>0)
assert copies=={8:9}
paid=forward+copies
price=json.loads((P/'kappa.json').read_text())
assert price['m']==56 and price['W']==10794 and price['T']==7 and price['K']==3
globalhist=collections.Counter({int(k):v for k,v in price['normalized_histogram'].items()})
expected=collections.Counter({k:49*v for k,v in paid.items()})
for rank in price['idle_blocks_per_role_pair']:expected[rank]+=2*120*7
assert globalhist==expected
result=dict(status='PASS_SOURCE_BOUND_COMMUTING_B_AND_REFLECTED_LEDGER',source_word_sha256=hashlib.sha256((P/'frozen376.json').read_bytes()).hexdigest(),candidate_word_sha256=hashlib.sha256((P/'reproduced-word.json.gz').read_bytes()).hexdigest(),same_fields=same,scalar_B_additions=592,exact_integer_operator_equivalence=True,integer_commutation_reason='All B targets lie in [120,240), all sources outside that range; every pair of transvection nilpotent parts has product zero.',forward_MOVE_histogram=dict(forward),reflected_MOVE_histogram=dict(reflected),copies=dict(copies),local_paid_histogram=dict(paid),local_paid_calls=sum(paid.values()),local_rank_mass=sum(k*v for k,v in paid.items()),seven_stage_histogram=dict(globalhist),seven_stage_calls=sum(globalhist.values()),seven_stage_rank_mass=sum(k*v for k,v in globalhist.items()),m=56,W=10794,deficit=56*10794-sum(k*v for k,v in globalhist.items()),price=price,scope='Exact commuting integer-operator equality to raw PR376. Does not establish that raw PR376 is the signed defining map; signed and global seven-stage admission are separate.')
(P/'AUDIT.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('price','same_fields')},sort_keys=True))
