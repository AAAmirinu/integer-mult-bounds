# P=3 pairs, k=6 alternating cross transvections over F_2: is any product block-antidiagonal (3v blocks, v=1)?
# Meet in the middle: W = A B, A = S6 S5 S4, B = S3 S2 S1. Condition: [A11 A12] annihilates [B11;B21] and [A21 A22] annihilates [B12;B22].
import itertools, sys
P=int(sys.argv[1]); K=int(sys.argv[2])
n=2*P
vecs=list(range(1,1<<P))  # nonzero vectors in F_2^P as bitmasks
# matrices as tuple of n row-bitmasks (bit j = column j); columns 0..P-1 = X block, P..2P-1 = Y block
def mul(A,B):
    # (AB)[i] = XOR over k in A[i] of B[k]
    out=[]
    for i in range(n):
        r=0; a=A[i]; k=0
        while a:
            if a&1: r^=B[k]
            a>>=1; k+=1
        out.append(r)
    return tuple(out)
I=tuple(1<<i for i in range(n))
def gen(typ,u,v):
    M=list(I)
    if typ=='L':   # Y rows += u * (v . X)
        for i in range(P):
            if u>>i&1: M[P+i]^=v          # v is a mask over X columns 0..P-1
    else:          # X rows += u * (v . Y)
        for i in range(P):
            if u>>i&1: M[i]^=(v<<P)
    return tuple(M)
GENS={t:[gen(t,u,v) for u in vecs for v in vecs] for t in 'LU'}
def products(types):  # types applied first-to-last; return list of matrices
    cur=[I]
    for t in types:
        cur=[mul(g,m) for m in cur for g in GENS[t]]
    return cur
def rowspace_basis(rows):
    # reduced echelon basis of a set of row-bitmasks over F_2 -> canonical tuple
    basis=[]
    for r in rows:
        for b in basis:
            r=min(r,r^b)
        if r:
            basis.append(r)
            basis.sort(reverse=True)
    # fully reduce
    basis=sorted(basis,reverse=True)
    for i in range(len(basis)):
        for j in range(len(basis)):
            if i!=j and basis[j]&(1<<(basis[i].bit_length()-1)) and basis[i].bit_length()>0:
                pass
    # simple canonical form: Gaussian elimination to RREF
    rows=list(basis); piv=[]
    rows2=[]
    for r in rows:
        for pr,pc in rows2:
            if r>>pc&1: r^=pr
        if r:
            pc=r.bit_length()-1
            rows2=[((pr^r) if pr>>pc&1 else pr,ppc) for pr,ppc in rows2]
            rows2.append((r,pc))
    return tuple(sorted(r for r,_ in rows2))
def kernel(rows):
    # kernel of the linear map x -> (row . x) for the given rows (rows are bitmasks over n columns); returns canonical basis
    # solve by enumerating all 2^n vectors (n<=6: 64) -- fine
    ker=[x for x in range(1<<n) if all(bin(r&x).count('1')%2==0 for r in rows)]
    return rowspace_basis(ker)
def colspace(M,cols):
    # column space of the submatrix with the given columns: vectors indexed by rows
    vs=[]
    for c in cols:
        v=0
        for i in range(n):
            if M[i]>>c&1: v|=1<<i
        vs.append(v)
    return rowspace_basis(vs)
Xc=list(range(P)); Yc=list(range(P,2*P))
found=0
for pattern in ((['L','U']*K)[:K],(['U','L']*K)[:K]):
    Btypes=pattern[:K//2]; Atypes=pattern[K//2:]
    Bs=products(Btypes); As=products(Atypes)
    table={}
    for B in Bs:
        key=(colspace(B,Xc),colspace(B,Yc))
        table.setdefault(key,B)
    for A in As:
        K1=kernel(A[:P]); K2=kernel(A[P:])
        key=(K1,K2)
        if key in table:
            B=table[key]; W=mul(A,B)
            # verify block antidiagonal + invertible blocks (check that W11=W22=0)
            ok=all((W[i]&((1<<P)-1))==0 for i in range(P)) and all((W[i]>>P)==0 for i in range(P,n))
            if ok:
                found+=1
                if found<=2: print('FOUND pattern',pattern,'W=',[bin(r) for r in W])
    print('pattern',pattern,'|A|',len(As),'|B|',len(Bs),'found so far',found,flush=True)
print('P',P,'k',K,'alternating solutions found:',found)
