import itertools
def mat_mul(A,B,q):
    return tuple(tuple(sum(A[i][k]*B[k][j] for k in range(4))%q for j in range(4)) for i in range(4))
def det2(a,b,c,d,q): return (a*d-b*c)%q
def inv4(M,q):
    n=4; A=[list(M[i])+[1 if i==j else 0 for j in range(n)] for i in range(n)]
    for c in range(n):
        p=next((r for r in range(c,n) if A[r][c]%q),None)
        if p is None: return None
        A[c],A[p]=A[p],A[c]; iv=pow(A[c][c],q-2,q); A[c]=[(x*iv)%q for x in A[c]]
        for r in range(n):
            if r!=c and A[r][c]%q:
                f=A[r][c]; A[r]=[(A[r][j]-f*A[c][j])%q for j in range(2*n)]
    return tuple(tuple(A[i][n:]) for i in range(n))
def run(q):
    vecs=[v for v in itertools.product(range(q),repeat=2) if any(v)]
    gens=[]
    for u in vecs:
        for v in vecs:
            M=[[int(i==j) for j in range(4)] for i in range(4)]
            for i in range(2):
                for j in range(2): M[2+i][j]=(u[i]*v[j])%q
            gens.append(('Y+=X',tuple(map(tuple,M))))
            M=[[int(i==j) for j in range(4)] for i in range(4)]
            for i in range(2):
                for j in range(2): M[i][2+j]=(u[i]*v[j])%q
            gens.append(('X+=Y',tuple(map(tuple,M))))
    two={}
    for n1,g1 in gens:
        for n2,g2 in gens:
            two.setdefault(mat_mul(g2,g1,q),[]).append((n1,n2))
    GL=[m for m in itertools.product(range(q),repeat=4) if det2(*m,q)]
    found=0; ex=None
    for C in GL:
        for E in GL:
            W=((0,0,C[0],C[1]),(0,0,C[2],C[3]),(E[0],E[1],0,0),(E[2],E[3],0,0))
            for P1,seqs in two.items():
                P2=mat_mul(W,inv4(P1,q),q)
                if P2 in two:
                    found+=1
                    if ex is None: ex=(W,seqs[0],two[P2][0])
    print('q',q,'|two|',len(two),'length-4 solutions (W,P1 pairs):',found,'example',ex,flush=True)
    f3=0
    for C in GL:
        for E in GL:
            W=((0,0,C[0],C[1]),(0,0,C[2],C[3]),(E[0],E[1],0,0),(E[2],E[3],0,0))
            for n,g in gens:
                if mat_mul(inv4(g,q),W,q) in two: f3+=1
    print('length-3 solutions',f3,flush=True)
run(2)
run(3)
