exec(open('/tmp/radical/M_idle.py').read().split("print('q',q,'K',K)")[0])
pats=[['both','none','X','both','none','both'],['both','none','Y','both','none','both'],['both','X','none','both','none','both'],['both','Y','none','both','none','both'],
      ['both','X','X','both','none','both'],['both','Y','Y','both','none','both'],['none','none','both','both','none','both'],['both','none','both','both','none','both'],
      ['both','both','none','both','none','both'],['both','X','Y','both','none','both'],['both','Y','X','both','none','both']]
for pat in pats: print(pat,'->',reachable(pat),flush=True)
