# Port-mixing extension of the merged-idle test: v ports, pair-1 three stages with no bridges between (D1=D2=I),
# D0 = (a0 x I_v on X, B0 arbitrary GL_2v on Y), then two pair-2 stages with arbitrary bridges D3,D4,D5.
# Criterion: Q = T D0^{-1} (S^{-1} (+) I) in G . L(E) D U(F) . G  (or U D L) with rank E,F <= v.
import itertools, random, sys
import numpy as np
q=int(sys.argv[1]); v=int(sys.argv[2]); trials=int(sys.argv[3])
rng=random.Random(1)
def rank(M):
    M=[list(r) for r in M]; n=len(M); m=len(M[0]); r=0
    for c in range(m):
        p=next((i for i in range(r,n) if M[i][c]%q),None)
        if p is None: continue
        M[r],M[p]=M[p],M[r]; iv=pow(M[r][c],q-2,q); M[r]=[(x*iv)%q for x in M[r]]
        for i in range(n):
            if i!=r and M[i][c]%q:
                f=M[i][c]; M[i]=[(M[i][j]-f*M[r][j])%q for j in range(m)]
        r+=1
    return r
def inv(M):
    n=len(M); A=[list(M[i])+[int(i==j) for j in range(n)] for i in range(n)]
    for c in range(n):
        p=next((i for i in range(c,n) if A[i][c]%q),None)
        if p is None: return None
        A[c],A[p]=A[p],A[c]; iv=pow(A[c][c],q-2,q); A[c]=[(x*iv)%q for x in A[c]]
        for i in range(n):
            if i!=c and A[i][c]%q:
                f=A[i][c]; A[i]=[(A[i][j]-f*A[c][j])%q for j in range(2*n)]
    return [r[n:] for r in A]
def mul(A,B): return [[sum(A[i][k]*B[k][j] for k in range(len(B)))%q for j in range(len(B[0]))] for i in range(len(A))]
def sub(A,B): return [[(A[i][j]-B[i][j])%q for j in range(len(A[0]))] for i in range(len(A))]
n=4*v  # rows: X1 (v), X2 (v), Y1 (v), Y2 (v)
def eye(k): return [[int(i==j) for j in range(k)] for i in range(k)]
def kron(a,k):  # 2x2 (on slots) kron I_k within a block of 2 slots
    M=[[0]*(2*k) for _ in range(2*k)]
    for i in range(2):
        for j in range(2):
            for t in range(k): M[i*k+t][j*k+t]=a[i][j]%q
    return M
def blockdiag(A,B):
    k=len(A); M=[[0]*(2*k) for _ in range(2*k)]
    for i in range(k):
        for j in range(k): M[i][j]=A[i][j]; M[k+i][k+j]=B[i][j]
    return M
# T: X1->-Y1... rows X1=-y1, X2=-y2, Y1=x1, Y2=x2  (block antidiag [[0,-I],[I,0]])
T=[[0]*n for _ in range(n)]
for t in range(2*v): T[t][2*v+t]=(-1)%q; T[2*v+t][t]=1
def stage1(typ,s):  # transvection on pair 1 (slot X1 rows 0..v-1, Y1 rows 2v..3v-1)
    M=eye(n)
    for t in range(v):
        if typ=='L': M[2*v+t][t]=s%q
        else: M[t][2*v+t]=s%q
    return M
signs=[1,q-1] if q>2 else [1]
S_list=[]
for types in itertools.product('LU',repeat=3):
    for ss in itertools.product(signs,repeat=3):
        M=eye(n)
        for ty,s in zip(types,ss): M=mul(stage1(ty,s),M)
        S_list.append((types,ss,M))
GL2=[a for a in itertools.product(range(q),repeat=4) if (a[0]*a[3]-a[1]*a[2])%q]
def randGL(k):
    while True:
        M=[[rng.randrange(q) for _ in range(k)] for _ in range(k)]
        if rank(M)==k: return M
def blocks(Q):
    h=n//2
    return [[Q[i][j] for j in range(h)] for i in range(h)],[[Q[i][j] for j in range(h,n)] for i in range(h)],[[Q[i][j] for j in range(h)] for i in range(h,n)],[[Q[i][j] for j in range(h,n)] for i in range(h,n)]
def feasible(Q):
    Q11,Q12,Q21,Q22=blocks(Q)
    if rank(Q12)>v or rank(Q21)>v: return False
    if rank(Q11)==2*v:
        Si=inv(Q11); sc=sub(Q22,mul(mul(Q21,Si),Q12))
        if rank(sc)==2*v: return True
    if rank(Q22)==2*v:
        Si=inv(Q22); sc=sub(Q11,mul(mul(Q12,Si),Q21))
        if rank(sc)==2*v: return True
    return False
found=0; tested=0
for trial in range(trials):
    B0=randGL(2*v)
    for a0 in GL2:
        A0=kron([[a0[0],a0[1]],[a0[2],a0[3]]],v)
        D0inv=blockdiag(A0,B0)
        for types,ss,S in S_list:
            Sinv=inv(S)
            Q=mul(mul(T,D0inv),Sinv)
            tested+=1
            if feasible(Q):
                found+=1
                if found<=3: print('FEASIBLE',types,ss,a0,B0)
print('q',q,'v',v,'tested',tested,'feasible',found)
