# Over F_q: which free-bridge positions are necessary for a 5-stage (or k-stage) swap of two pairs?
# rows: X1=0, X2=1, Y1=2, Y2=3. Word stage on pair j: L-type Y_j += s X_j, U-type X_j += s Y_j.
# Free bridges at position i: block-diagonal diag(A,B), A on (X1,X2), B on (Y1,Y2); restricted to X-only, Y-only, none, both.
import itertools, sys
q=int(sys.argv[1]) if len(sys.argv)>1 else 2
K=int(sys.argv[2]) if len(sys.argv)>2 else 5
def mul(A,B): return tuple(tuple(sum(A[i][k]*B[k][j] for k in range(4))%q for j in range(4)) for i in range(4))
I4=tuple(tuple(int(i==j) for j in range(4)) for i in range(4))
GL2=[m for m in itertools.product(range(q),repeat=4) if (m[0]*m[3]-m[1]*m[2])%q]
def blockdiag(A,B):
    M=[[0]*4 for _ in range(4)]
    M[0][0],M[0][1],M[1][0],M[1][1]=A
    M[2][2],M[2][3],M[3][2],M[3][3]=B
    return tuple(map(tuple,M))
E2=(1,0,0,1)
GROUPS={'none':[I4],'X':[blockdiag(A,E2) for A in GL2],'Y':[blockdiag(E2,B) for B in GL2],'both':[blockdiag(A,B) for A in GL2 for B in GL2]}
def stage(pair,typ,s):
    M=[list(r) for r in I4]
    x,y=(0,2) if pair==1 else (1,3)
    if typ=='L': M[y][x]=s%q
    else: M[x][y]=s%q
    return tuple(map(tuple,M))
signs=[1,q-1] if q>2 else [1]
STAGES=[stage(p,t,s) for p in (1,2) for t in 'LU' for s in signs]
# target: block antidiagonal with invertible blocks, i.e. T up to both-sided block-diag; we just test membership in the set
targets=set()
for A in GL2:
    for B in GL2:
        M=[[0]*4 for _ in range(4)]
        M[0][2],M[0][3],M[1][2],M[1][3]=A
        M[2][0],M[2][1],M[3][0],M[3][1]=B
        targets.add(tuple(map(tuple,M)))
def reachable(pattern):
    # pattern: list of K+1 group names (positions 0..K)
    cur={I4}
    for i in range(K):
        cur={mul(g,m) for m in cur for g in GROUPS[pattern[i]]}
        cur={mul(s,m) for m in cur for s in STAGES}
    cur={mul(g,m) for m in cur for g in GROUPS[pattern[K]]}
    return bool(cur & targets)
print('q',q,'K',K)
full=['both']*(K+1)
print('all bridges free:',reachable(full))
# single-position restrictions
for i in range(K+1):
    for g in ('none','X','Y'):
        pat=list(full); pat[i]=g
        print('position',i,'restricted to',g,'->',reachable(pat))

print('--- specific patterns (positions 0..K) ---')
for pat in (['both','none','none','both','none','both'],['none','none','none','both','none','both'],['both','none','none','both','both','both'],['none','none','none','both','both','both'],['both','none','none','X','none','both'],['both','none','none','Y','none','both'],['none','none','none','none','none','both'],['both','none','none','none','none','both']):
    if len(pat)==K+1: print(pat,'->',reachable(pat))
